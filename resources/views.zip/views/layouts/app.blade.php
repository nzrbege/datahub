<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Sistem Data Keluarga') - {{ config('app.name') }}</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
            --primary: #155e75;
            --primary-light: #0891b2;
            --accent: #be123c;
            --bg: #f6f8fb;
            --sidebar-w: 260px;
            --card-bg: #fff;
            --border: #e5e7eb;
            --text: #111827;
            --text-muted: #6b7280;
            --success: #15803d;
            --danger: #dc2626;
            --warning: #d97706;
            --info: #0284c7;
        }
        body { font-family: 'Inter', 'Segoe UI', sans-serif; background: var(--bg); color: var(--text); display: flex; min-height: 100vh; }

        /* Sidebar */
        .sidebar { width: var(--sidebar-w); background: #0f172a; color: #fff; display: flex; flex-direction: column; position: fixed; top: 0; bottom: 0; left: 0; overflow-y: auto; z-index: 100; box-shadow: 12px 0 30px rgba(15,23,42,.12); }
        .sidebar-brand { padding: 20px 16px; border-bottom: 1px solid rgba(255,255,255,.15); }
        .sidebar-brand h1 { font-size: 15px; font-weight: 700; line-height: 1.4; letter-spacing:.2px; }
        .sidebar-brand .badge-pdp { background: var(--accent); font-size: 10px; padding: 2px 6px; border-radius: 3px; display: inline-block; margin-top: 4px; }
        .sidebar-user { padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,.1); font-size: 12px; }
        .sidebar-user strong { display: block; font-size: 13px; }
        .sidebar-user .role-badge { background: rgba(34,211,238,.18); color:#a5f3fc; padding: 3px 9px; border-radius: 999px; margin-top: 6px; display: inline-block; }
        .sidebar nav { flex: 1; padding: 10px 0; }
        .nav-section { padding: 10px 16px 4px; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: rgba(255,255,255,.5); }
        .nav-item a { display: flex; align-items: center; gap: 10px; margin: 2px 10px; padding: 10px 12px; color: rgba(255,255,255,.78); text-decoration: none; font-size: 13px; border-radius: 8px; transition: background .15s, color .15s; }
        .nav-item a:hover, .nav-item a.active { background: rgba(255,255,255,.12); color: #fff; }
        .nav-item a i { width: 18px; text-align: center; }
        .sidebar-footer { padding: 12px 16px; border-top: 1px solid rgba(255,255,255,.1); font-size: 11px; color: rgba(255,255,255,.5); }
        .sidebar-footer a { color: rgba(255,255,255,.6); text-decoration: none; }

        /* Main */
        .main-wrap { margin-left: var(--sidebar-w); flex: 1; display: flex; flex-direction: column; }
        .topbar { background: rgba(255,255,255,.92); backdrop-filter: blur(10px); border-bottom: 1px solid var(--border); padding: 14px 24px; display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 50; }
        .topbar-title { font-size: 18px; font-weight: 700; }
        .topbar-right { display: flex; align-items: center; gap: 16px; font-size: 13px; color: var(--text-muted); }
        .main-content { padding: 24px; flex: 1; max-width: 1480px; width: 100%; }

        /* Cards */
        .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 10px 28px rgba(15,23,42,.04); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border); }
        .card-title { font-size: 15px; font-weight: 600; }

        /* Stats */
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: #fff; border: 1px solid var(--border); border-radius: 10px; padding: 18px; display: flex; align-items: center; gap: 14px; box-shadow: 0 8px 22px rgba(15,23,42,.04); }
        .stat-icon { width: 46px; height: 46px; border-radius: 9px; display: flex; align-items: center; justify-content: center; font-size: 19px; }
        .stat-icon.blue   { background: #e3f2fd; color: #1565c0; }
        .stat-icon.green  { background: #e8f5e9; color: #2e7d32; }
        .stat-icon.orange { background: #fff3e0; color: #e65100; }
        .stat-icon.red    { background: #ffebee; color: #c62828; }
        .stat-num { font-size: 26px; font-weight: 700; }
        .stat-label { font-size: 12px; color: var(--text-muted); }

        /* Table */
        .table-wrap { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th { background: #f9fafb; padding: 10px 12px; text-align: left; font-weight: 600; border-bottom: 2px solid var(--border); white-space: nowrap; color:#374151; }
        td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
        tr:hover td { background: #fafbfc; }

        /* Badges */
        .badge { display: inline-block; padding: 3px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }
        .badge-pending  { background: #fff3cd; color: #856404; }
        .badge-approved { background: #d1e7dd; color: #0f5132; }
        .badge-rejected { background: #f8d7da; color: #842029; }
        .badge-revoked  { background: #e2e3e5; color: #41464b; }
        .badge-active   { background: #d1e7dd; color: #0f5132; }
        .badge-inactive { background: #f8d7da; color: #842029; }
        .badge-sa       { background: #cfe2ff; color: #084298; }
        .badge-admin    { background: #e2e3e5; color: #41464b; }

        /* Buttons */
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; border: none; cursor: pointer; font-size: 13px; font-weight: 600; text-decoration: none; transition: opacity .15s, transform .15s; }
        .btn:hover { opacity: .9; transform: translateY(-1px); }
        .btn-primary  { background: var(--primary); color: #fff; }
        .btn-danger   { background: var(--danger); color: #fff; }
        .btn-success  { background: var(--success); color: #fff; }
        .btn-warning  { background: var(--warning); color: #212529; }
        .btn-outline  { background: transparent; color: var(--primary); border: 1px solid var(--primary); }
        .btn-sm       { padding: 5px 10px; font-size: 12px; }

        /* Forms */
        .form-group { margin-bottom: 16px; }
        .form-label { display: block; font-size: 13px; font-weight: 500; margin-bottom: 5px; }
        .form-label .required { color: var(--accent); }
        .form-control { width: 100%; padding: 8px 12px; border: 1px solid var(--border); border-radius: 8px; font-size: 13px; }
        .form-control:focus { outline: none; border-color: var(--primary-light); box-shadow: 0 0 0 3px rgba(45,90,142,.15); }
        .form-text { font-size: 11px; color: var(--text-muted); margin-top: 4px; }
        .invalid-feedback { color: var(--danger); font-size: 12px; margin-top: 4px; }
        textarea.form-control { resize: vertical; min-height: 100px; }

        /* Alerts */
        .alert { padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; font-size: 13px; border: 1px solid transparent; display: flex; gap: 10px; align-items: flex-start; }
        .alert-success { background: #d1e7dd; color: #0f5132; border-color: #a3cfbb; }
        .alert-danger  { background: #f8d7da; color: #842029; border-color: #f1aeb5; }
        .alert-warning { background: #fff3cd; color: #664d03; border-color: #ffda6a; }
        .alert-info    { background: #cff4fc; color: #055160; border-color: #9eeaf9; }

        /* Pagination */
        .pagination { display: flex; gap: 4px; list-style: none; padding: 0; justify-content: center; margin-top: 16px; }
        .pagination a, .pagination span { padding: 6px 12px; border: 1px solid var(--border); border-radius: 4px; font-size: 13px; text-decoration: none; color: var(--primary); }
        .pagination .active span { background: var(--primary); color: #fff; border-color: var(--primary); }

        /* UU PDP Notice */
        .pdp-notice { background: #fffbeb; border: 1px solid #fde68a; border-left: 4px solid #d97706; border-radius: 10px; padding: 12px 16px; font-size: 12px; margin-bottom: 20px; }
        .pdp-notice strong { color: #92400e; }

        .section-grid { display:grid; grid-template-columns:minmax(0, 2fr) minmax(300px, 1fr); gap:20px; align-items:start; }
        .dataset-grid { display:grid; grid-template-columns:repeat(auto-fill, minmax(260px, 1fr)); gap:14px; }
        .dataset-card { border:1px solid var(--border); border-radius:10px; padding:14px; background:#fff; display:flex; flex-direction:column; gap:10px; min-height:170px; }
        .dataset-card__top { display:flex; justify-content:space-between; gap:10px; align-items:flex-start; }
        .dataset-card__title { font-size:14px; font-weight:700; line-height:1.35; }
        .dataset-meta { display:flex; flex-wrap:wrap; gap:6px; color:var(--text-muted); font-size:11px; }
        .dataset-meta span { background:#f3f4f6; border-radius:999px; padding:3px 8px; }
        .empty-state { border:1px dashed #cbd5e1; border-radius:10px; padding:24px; text-align:center; background:#f8fafc; color:var(--text-muted); }
        .empty-state i { font-size:30px; color:#94a3b8; margin-bottom:10px; }
        .quick-list { display:flex; flex-direction:column; gap:10px; }
        .quick-list__item { display:flex; justify-content:space-between; gap:12px; align-items:center; padding:11px 0; border-bottom:1px solid #f1f5f9; }
        .quick-list__item:last-child { border-bottom:none; }

        @media (max-width: 900px) {
            .sidebar { position: static; width: 100%; min-height: auto; }
            body { display: block; }
            .main-wrap { margin-left: 0; }
            .topbar { align-items:flex-start; gap:10px; flex-direction:column; }
            .topbar-right { flex-wrap:wrap; gap:8px; }
            .main-content { padding: 16px; }
            .section-grid { grid-template-columns:1fr; }
            .card-header { align-items:flex-start; gap:10px; flex-direction:column; }
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-brand">
            <h1>Sistem Data Keluarga</h1>
        </div>
        <div class="sidebar-user">
            <strong>{{ auth()->user()->name }}</strong>
            <span>{{ auth()->user()->instansi }}</span>
            <div class="role-badge">{{ auth()->user()->getRoleNames()->first() === 'super_admin' ? 'Super Admin' : 'Admin' }}</div>
        </div>
        <nav>
            @if(auth()->user()->isSuperAdmin())
                <div class="nav-section">Utama</div>
                <div class="nav-item"><a href="{{ route('superadmin.dashboard') }}" class="{{ request()->routeIs('superadmin.dashboard') ? 'active' : '' }}"><i class="fas fa-tachometer-alt"></i> Dashboard</a></div>

                <div class="nav-section">Data</div>
                <div class="nav-item"><a href="{{ route('superadmin.files.index') }}" class="{{ request()->routeIs('superadmin.files.*') ? 'active' : '' }}"><i class="fas fa-database"></i> File Data</a></div>

                <div class="nav-section">Permintaan</div>
                <div class="nav-item"><a href="{{ route('superadmin.requests.index') }}" class="{{ request()->routeIs('superadmin.requests.*') ? 'active' : '' }}"><i class="fas fa-inbox"></i> Permintaan Data</a></div>

                <div class="nav-section">Manajemen</div>
                <div class="nav-item"><a href="{{ route('superadmin.users.index') }}" class="{{ request()->routeIs('superadmin.users.*') ? 'active' : '' }}"><i class="fas fa-users"></i> Pengguna</a></div>

                <div class="nav-section">Kepatuhan</div>
                <div class="nav-item"><a href="{{ route('superadmin.audit.index') }}" class="{{ request()->routeIs('superadmin.audit.index') || request()->routeIs('superadmin.audit.export') ? 'active' : '' }}"><i class="fas fa-clipboard-list"></i> Log Aktivitas</a></div>
                <div class="nav-item"><a href="{{ route('superadmin.audit.downloads') }}" class="{{ request()->routeIs('superadmin.audit.downloads') || request()->routeIs('superadmin.audit.downloads.export') ? 'active' : '' }}"><i class="fas fa-download"></i> Log Download</a></div>
            @else
                <div class="nav-section">Utama</div>
                <div class="nav-item"><a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"><i class="fas fa-tachometer-alt"></i> Dashboard</a></div>

                <div class="nav-section">Data</div>
                <div class="nav-item"><a href="{{ route('admin.requests.index') }}" class="{{ request()->routeIs('admin.requests.*') ? 'active' : '' }}"><i class="fas fa-file-contract"></i> Permintaan Data</a></div>
                <div class="nav-item"><a href="{{ route('admin.requests.create') }}"><i class="fas fa-plus-circle"></i> Ajukan Permintaan</a></div>
            @endif
        </nav>
        <div class="sidebar-footer">
            <div>⏱ {{ now()->format('d/m/Y H:i') }}</div>
            <div style="margin-top:6px;"><a href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit()"><i class="fas fa-sign-out-alt"></i> Keluar</a></div>
        </div>
    </aside>

    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display:none">@csrf</form>

    <!-- Main -->
    <div class="main-wrap">
        <div class="topbar">
            <span class="topbar-title">@yield('page-title', 'Dashboard')</span>
            <div class="topbar-right">
                <i class="fas fa-lock" style="color:var(--success)"></i> Data Terenkripsi
                <span>|</span>
                <i class="fas fa-user-shield"></i> {{ auth()->user()->name }}
            </div>
        </div>
        <div class="main-content">
            @if(session('success'))
                <div class="alert alert-success"><i class="fas fa-check-circle"></i> {{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> {{ session('error') }}</div>
            @endif
            @if($errors->any())
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>@foreach($errors->all() as $e)<div>{{ $e }}</div>@endforeach</div>
                </div>
            @endif
            @yield('content')
        </div>
    </div>
    @stack('scripts')
</body>
</html>
