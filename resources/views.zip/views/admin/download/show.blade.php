@extends('layouts.app')
@section('page-title', 'Unduh File Data')

@section('content')
<div class="pdp-notice">
    <strong>🔒 Peringatan UU PDP:</strong> Anda akan mengunduh data pribadi yang dilindungi undang-undang. Penggunaan di luar tujuan yang disetujui merupakan pelanggaran hukum. Aktivitas ini dicatat dalam audit log.
</div>

<div style="max-width:500px; margin:0 auto;">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-download"></i> Unduh File Data</span>
        </div>

        <!-- Info File -->
        <div style="background:#f8f9fa; border-radius:6px; padding:16px; margin-bottom:20px; font-size:13px;">
            <table style="width:100%; border:none;">
                <tr><td style="color:#6c757d; padding:4px 0; border:none; width:130px;">File</td><td style="border:none;"><strong>{{ $dataRequest->dataFile->judul }}</strong></td></tr>
                <tr><td style="color:#6c757d; padding:4px 0; border:none;">Jenis Dataset</td><td style="border:none;">{{ $dataRequest->dataFile->kategori_label }}</td></tr>
                <tr><td style="color:#6c757d; padding:4px 0; border:none;">Ukuran</td><td style="border:none;">{{ $dataRequest->dataFile->file_size_human }}</td></tr>
                <tr><td style="color:#6c757d; padding:4px 0; border:none;">Sisa Download</td><td style="border:none;"><strong style="color:#c8102e;">{{ $dataRequest->max_downloads - $dataRequest->download_count }}×</strong> dari {{ $dataRequest->max_downloads }}×</td></tr>
                <tr><td style="color:#6c757d; padding:4px 0; border:none;">Token Berlaku</td><td style="border:none;">{{ $dataRequest->token_expires_at?->format('d/m/Y H:i') }}</td></tr>
            </table>
        </div>

        <!-- Captcha Form -->
        <form action="{{ route('admin.download.process', $dataRequest) }}" method="POST">
            @csrf
            <div class="form-group">
                <label class="form-label">Verifikasi Captcha <span class="required">*</span></label>
                <div style="margin-bottom:10px;">
                    <img src="{{ captcha_src() }}" alt="Captcha" id="captchaImg"
                        style="border:1px solid #dee2e6; border-radius:4px; cursor:pointer;"
                        title="Klik untuk refresh" onclick="refreshCaptcha()">
                    <button type="button" onclick="refreshCaptcha()" style="background:none; border:none; color:#1e3a5f; cursor:pointer; font-size:12px; margin-left:8px;"><i class="fas fa-sync-alt"></i> Refresh</button>
                </div>
                <input type="text" name="captcha" class="form-control" placeholder="Masukkan kode di atas" autocomplete="off" required>
                @error('captcha')
                <div class="invalid-feedback" style="display:block;">{{ $message }}</div>
                @enderror
                <div class="form-text">Masukkan kode yang terlihat pada gambar. Kode bersifat case-sensitive.</div>
            </div>

            <div style="background:#fff3cd; border:1px solid #ffc107; border-radius:6px; padding:12px; font-size:12px; margin-bottom:16px;">
                <strong>⚠️ Perhatian:</strong> Dengan mengunduh file ini, Anda mengonfirmasi bahwa penggunaan data sesuai dengan permohonan yang telah disetujui dan Perjanjian Kerahasiaan yang ditandatangani.
            </div>

            <button type="submit" class="btn btn-success" style="width:100%;">
                <i class="fas fa-download"></i> Unduh File (Setelah Verifikasi Captcha)
            </button>
        </form>
    </div>

    <div style="text-align:center; margin-top:12px;">
        <a href="{{ route('admin.requests.show', $dataRequest) }}" style="color:#6c757d; font-size:13px;">← Kembali ke Detail Permintaan</a>
    </div>
</div>

@push('scripts')
<script>
function refreshCaptcha() {
    fetch('/captcha/refresh')
        .then(r => r.json())
        .then(d => {
            // Refresh via timestamp trick
            document.getElementById('captchaImg').src = '{{ captcha_src() }}' + '?r=' + Math.random();
        });
    document.getElementById('captchaImg').src = document.getElementById('captchaImg').src.split('?')[0] + '?r=' + Math.random();
}
</script>
@endpush
@endsection
