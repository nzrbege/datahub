@extends('layouts.app')
@section('page-title', 'Permintaan Data Saya')

@section('content')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-file-contract"></i> Riwayat Permintaan Akses Data</span>
        <a href="{{ route('admin.requests.create') }}" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Ajukan Permintaan
        </a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>File Data</th>
                    <th>Jenis Dataset</th>
                    <th>NDA</th>
                    <th>Diajukan</th>
                    <th>Status</th>
                    <th>Review</th>
                    <th>Download</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($requests as $req)
                <tr>
                    <td style="color:#adb5bd;">{{ $req->id }}</td>
                    <td>
                        <strong>{{ $req->dataFile->judul ?? '—' }}</strong>
                        <div style="font-size:11px; color:#adb5bd;">{{ $req->dataFile->tahun_data ?? '' }}</div>
                    </td>
                    <td>
                        <span class="badge" style="background:#e3f2fd; color:#1565c0;">
                            {{ $req->dataFile->kategori_label ?? '—' }}
                        </span>
                    </td>
                    <td style="text-align:center;">
                        <span title="{{ $req->nda_filename }}" style="color:#c62828;">
                            <i class="fas fa-file-pdf"></i>
                        </span>
                    </td>
                    <td style="font-size:12px; color:#6c757d; white-space:nowrap;">
                        {{ $req->created_at->format('d/m/Y H:i') }}
                    </td>
                    <td><span class="badge badge-{{ $req->status }}">{{ $req->status_label }}</span></td>
                    <td style="font-size:12px; color:#6c757d;">
                        @if($req->reviewed_at)
                            {{ $req->reviewed_at->format('d/m/Y') }}<br>
                            <span style="font-size:10px;">{{ $req->reviewer->name ?? '' }}</span>
                        @else
                            <span style="color:#adb5bd;">—</span>
                        @endif
                    </td>
                    <td style="text-align:center; font-size:12px;">
                        @if($req->isApproved())
                            @if($req->canDownload())
                                <span style="color:#0f5132; font-weight:600;">{{ $req->max_downloads - $req->download_count }}× tersisa</span>
                            @else
                                <span style="color:#adb5bd;">Habis/Kadaluarsa</span>
                            @endif
                        @else
                            <span style="color:#adb5bd;">—</span>
                        @endif
                    </td>
                    <td>
                        <div style="display:flex; gap:4px;">
                            <a href="{{ route('admin.requests.show', $req) }}" class="btn btn-sm btn-outline" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            @if($req->canDownload())
                            <a href="{{ route('admin.download.show', $req) }}" class="btn btn-sm btn-success" title="Unduh">
                                <i class="fas fa-download"></i>
                            </a>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="9" style="text-align:center; color:#adb5bd; padding:32px;">
                        Belum ada permintaan. <a href="{{ route('admin.requests.create') }}">Ajukan sekarang</a>
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;">{{ $requests->links() }}</div>
</div>
@endsection
