@extends('layouts.app')
@section('page-title', 'Detail Permintaan')

@section('content')
<div style="max-width:800px; margin:0 auto;">
    <div class="card">
        <div class="card-header">
            <span class="card-title">📋 Permintaan #{{ $dataRequest->id }}</span>
            <div style="display:flex; gap:8px; align-items:center;">
                <span class="badge badge-{{ $dataRequest->status }}">{{ $dataRequest->status_label }}</span>
                <a href="{{ route('admin.requests.index') }}" class="btn btn-sm btn-outline">← Kembali</a>
            </div>
        </div>

        <!-- Info -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; font-size:13px; margin-bottom:20px;">
            <div>
                <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:4px;">File Data</div>
                <strong>{{ $dataRequest->dataFile->judul ?? '—' }}</strong>
                <div style="color:#6c757d; font-size:12px;">{{ $dataRequest->dataFile->kategori_label ?? '' }} · {{ $dataRequest->dataFile->tahun_data ?? '' }}</div>
            </div>
            <div>
                <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:4px;">Dasar Hukum</div>
                <span>{{ $dataRequest->dasar_hukum }}</span>
            </div>
            <div>
                <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:4px;">Tanggal Pengajuan</div>
                <span>{{ $dataRequest->created_at->format('d/m/Y H:i') }}</span>
            </div>
            <div>
                <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:4px;">NDA Terlampir</div>
                <span><i class="fas fa-file-pdf" style="color:#c62828;"></i> {{ $dataRequest->nda_filename }}</span>
            </div>
        </div>

        <div style="margin-bottom:14px;">
            <div style="font-size:12px; font-weight:600; color:#6c757d; margin-bottom:4px; text-transform:uppercase;">Alasan Permintaan</div>
            <div style="background:#f8f9fa; padding:12px; border-radius:4px; font-size:13px; line-height:1.6;">{{ $dataRequest->alasan_permintaan }}</div>
        </div>
        <div style="margin-bottom:14px;">
            <div style="font-size:12px; font-weight:600; color:#6c757d; margin-bottom:4px; text-transform:uppercase;">Tujuan Penggunaan</div>
            <div style="background:#f8f9fa; padding:12px; border-radius:4px; font-size:13px; line-height:1.6;">{{ $dataRequest->tujuan_penggunaan }}</div>
        </div>

        @if($dataRequest->catatan_reviewer)
        <div style="background:{{ $dataRequest->isApproved() ? '#d1e7dd' : '#f8d7da' }}; padding:12px; border-radius:6px; font-size:13px; margin-bottom:14px;">
            <strong>Catatan Reviewer ({{ $dataRequest->reviewer->name ?? '—' }}, {{ $dataRequest->reviewed_at?->format('d/m/Y H:i') }}):</strong><br>
            {{ $dataRequest->catatan_reviewer }}
        </div>
        @endif

        <!-- Action: Download jika disetujui -->
        @if($dataRequest->isApproved())
            @if($dataRequest->canDownload())
            <div style="background:#d1e7dd; border:1px solid #a3cfbb; border-radius:6px; padding:16px; text-align:center;">
                <div style="color:#0f5132; font-weight:600; margin-bottom:8px;">✅ Permintaan Disetujui — Siap Diunduh</div>
                <div style="font-size:12px; color:#146c43; margin-bottom:12px;">
                    Sisa download: <strong>{{ $dataRequest->max_downloads - $dataRequest->download_count }}×</strong> |
                    Token berlaku sampai: {{ $dataRequest->token_expires_at?->format('d/m/Y H:i') ?? 'N/A' }}
                </div>
                <a href="{{ route('admin.download.show', $dataRequest) }}" class="btn btn-success">
                    <i class="fas fa-download"></i> Unduh File (Verifikasi Captcha)
                </a>
            </div>
            @else
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i>
                Link download telah kadaluarsa atau batas download ({{ $dataRequest->max_downloads }}×) telah tercapai. Hubungi Super Admin jika masih membutuhkan akses.
            </div>
            @endif
        @elseif($dataRequest->isPending())
        <div class="alert alert-info">
            <i class="fas fa-clock"></i>
            Permintaan Anda sedang ditinjau oleh Super Admin. Anda akan diberitahu setelah ada keputusan.
        </div>
        @elseif($dataRequest->isRejected())
        <div class="alert alert-danger">
            <i class="fas fa-times-circle"></i>
            Permintaan ditolak. Periksa catatan reviewer di atas dan ajukan permintaan baru jika diperlukan.
        </div>
        @endif
    </div>

    <!-- Riwayat Download -->
    @if($dataRequest->downloadLogs->isNotEmpty())
    <div class="card">
        <div class="card-header"><span class="card-title">📥 Riwayat Unduhan Saya</span></div>
        <table style="font-size:12px; width:100%;">
            <thead><tr><th>Waktu</th><th>IP</th><th>Status</th></tr></thead>
            <tbody>
                @foreach($dataRequest->downloadLogs as $log)
                <tr>
                    <td>{{ $log->downloaded_at->format('d/m/Y H:i:s') }}</td>
                    <td style="font-family:monospace;">{{ $log->ip_address }}</td>
                    <td><span class="badge badge-{{ $log->status === 'success' ? 'approved' : 'rejected' }}">{{ $log->status }}</span></td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    @endif
</div>
@endsection
