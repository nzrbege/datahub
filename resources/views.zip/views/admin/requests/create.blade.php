@extends('layouts.app')
@section('page-title', 'Ajukan Permintaan Data')

@section('content')
<div class="pdp-notice">
    <strong>⚖️ Dasar Hukum UU PDP No.27/2022:</strong> Permohonan akses data pribadi wajib menyertakan alasan yang jelas, dasar hukum penggunaan, tujuan pemrosesan, dan Perjanjian Kerahasiaan (NDA). Seluruh akses akan tercatat dalam audit log.
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-file-contract"></i> Formulir Permintaan Akses Data</span>
        <a href="{{ route('admin.requests.index') }}" class="btn btn-sm btn-outline"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>

    <form action="{{ route('admin.requests.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
            <div>
                <div class="form-group">
                    <label class="form-label">File Data yang Diminta <span class="required">*</span></label>
                    <select name="data_file_id" class="form-control" required>
                        <option value="">— Pilih File —</option>
                        @foreach($availableFiles as $file)
                        <option value="{{ $file->id }}" {{ old('data_file_id')==$file->id?'selected':'' }}>
                            {{ $file->judul }} ({{ $file->kategori_label }}, {{ $file->tahun_data ?? '—' }})
                        </option>
                        @endforeach
                    </select>
                    @if($availableFiles->isEmpty())
                    <div class="form-text" style="color:#842029;">Tidak ada file yang tersedia untuk Anda. Hubungi Super Admin untuk meminta akses.</div>
                    @endif
                </div>

                <div class="form-group">
                    <label class="form-label">Dasar Hukum Penggunaan <span class="required">*</span></label>
                    <input type="text" name="dasar_hukum" class="form-control" value="{{ old('dasar_hukum') }}"
                        placeholder="mis: Permendagri No.X/2024 Pasal Y">
                    <div class="form-text">Cantumkan peraturan yang menjadi dasar penggunaan data.</div>
                </div>
            </div>
            <div>
                <div class="form-group">
                    <label class="form-label">Dokumen Perjanjian Kerahasiaan (NDA) <span class="required">*</span></label>
                    <input type="file" name="nda_file" class="form-control" accept=".pdf" required>
                    <div class="form-text">Wajib PDF. Dokumen yang telah ditandatangani dan dicap institusi. Maks 5MB.</div>
                    <div id="ndaInfo" style="font-size:12px; color:#0f5132; margin-top:4px; display:none;"></div>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Alasan Permintaan <span class="required">*</span></label>
            <textarea name="alasan_permintaan" class="form-control" rows="4" required placeholder="Jelaskan secara detail mengapa data ini dibutuhkan (min. 50 karakter)...">{{ old('alasan_permintaan') }}</textarea>
        </div>

        <div class="form-group">
            <label class="form-label">Tujuan Penggunaan Data <span class="required">*</span></label>
            <textarea name="tujuan_penggunaan" class="form-control" rows="4" required placeholder="Jelaskan secara rinci untuk apa data ini akan digunakan, siapa yang akan mengaksesnya, dan bagaimana data akan disimpan dan dihancurkan setelah selesai (min. 50 karakter)...">{{ old('tujuan_penggunaan') }}</textarea>
            <div class="form-text">Sesuai UU PDP Pasal 20: tujuan pemrosesan harus spesifik, eksplisit, dan sah.</div>
        </div>

        <!-- Pernyataan -->
        <div style="background:#f8f9fa; border:1px solid #dee2e6; border-radius:6px; padding:16px; margin-bottom:20px;">
            <div style="font-size:13px; font-weight:600; margin-bottom:10px; color:#1e3a5f;">📋 Pernyataan Pemohon</div>
            <label style="display:flex; gap:10px; font-size:13px; cursor:pointer;">
                <input type="checkbox" required style="margin-top:2px; cursor:pointer;">
                <span>Saya menyatakan bahwa permohonan ini diajukan atas kepentingan tugas resmi instansi, data yang diterima tidak akan dibagikan kepada pihak yang tidak berwenang, dan saya tunduk pada ketentuan UU PDP No.27/2022 serta perjanjian kerahasiaan yang dilampirkan.</span>
            </label>
        </div>

        <div style="display:flex; gap:10px;">
            <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Kirim Permintaan</button>
            <a href="{{ route('admin.requests.index') }}" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

@push('scripts')
<script>
document.querySelector('[name=nda_file]').addEventListener('change', function(e) {
    const f = e.target.files[0];
    if (f) {
        document.getElementById('ndaInfo').style.display = 'block';
        document.getElementById('ndaInfo').textContent = `✅ ${f.name} (${(f.size/1024).toFixed(0)} KB)`;
    }
});
</script>
@endpush
@endsection
