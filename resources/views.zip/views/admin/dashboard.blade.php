@extends('layouts.app')
@section('page-title', 'Dashboard Admin')

@section('content')
@php
    $user = auth()->user();
    $accessibleFiles = $user->accessibleFiles()
        ->where('data_files.is_active', true)
        ->latest('data_files.created_at')
        ->get();

    $recentRequests = $user->dataRequests()
        ->with('dataFile')
        ->latest()
        ->limit(5)
        ->get();
    $recentRequests->each->ensureDownloadToken();

    $activeRequests = $user->dataRequests()
        ->whereIn('status', ['pending', 'approved'])
        ->get()
        ->keyBy('data_file_id');

    $totalRequests = $user->dataRequests()->count();
    $pendingRequests = $user->dataRequests()->where('status', 'pending')->count();
    $approvedRequests = $user->dataRequests()->where('status', 'approved')->count();
    $downloads = \App\Models\DownloadLog::where('user_id', $user->id)->where('status', 'success')->count();
@endphp

<div class="pdp-notice">
    <strong>UU PDP No.27/2022:</strong> Anda berperan sebagai penerima data. Akses dataset hanya digunakan sesuai tujuan yang disetujui dan seluruh unduhan tercatat.
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-database"></i></div>
        <div><div class="stat-num">{{ $accessibleFiles->count() }}</div><div class="stat-label">Dataset Diberi Akses</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
        <div><div class="stat-num">{{ $pendingRequests }}</div><div class="stat-label">Menunggu Persetujuan</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
        <div><div class="stat-num">{{ $approvedRequests }}</div><div class="stat-label">Permintaan Disetujui</div></div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-download"></i></div>
        <div><div class="stat-num">{{ $downloads }}</div><div class="stat-label">File Diunduh</div></div>
    </div>
</div>

<div class="section-grid">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-database"></i> Dataset yang Diberikan Akses</span>
            <a href="{{ route('admin.requests.create') }}" class="btn btn-sm btn-primary">
                <i class="fas fa-paper-plane"></i> Ajukan Permintaan Data
            </a>
        </div>

        @if($accessibleFiles->isNotEmpty())
            <div class="dataset-grid">
                @foreach($accessibleFiles as $file)
                    @php $requestForFile = $activeRequests->get($file->id); @endphp
                    <div class="dataset-card">
                        <div class="dataset-card__top">
                            <div>
                                <div class="dataset-card__title">{{ $file->judul }}</div>
                                <div style="font-size:11px; color:#6b7280; margin-top:4px;">{{ $file->original_filename }}</div>
                            </div>
                            <i class="fas fa-lock" style="color:#15803d;" title="Terenkripsi"></i>
                        </div>

                        <div class="dataset-meta">
                            <span>{{ $file->kategori_label }}</span>
                            <span>{{ $file->tahun_data ?? 'Periode -' }}</span>
                            <span>{{ $file->file_size_human }}</span>
                        </div>

                        <div style="font-size:12px; color:#6b7280; line-height:1.5; flex:1;">
                            {{ \Illuminate\Support\Str::limit($file->deskripsi ?: 'Dataset tersedia untuk diajukan melalui permintaan resmi.', 120) }}
                        </div>

                        <div style="display:flex; justify-content:space-between; gap:8px; align-items:center;">
                            @if($requestForFile)
                                <span class="badge badge-{{ $requestForFile->status }}">{{ $requestForFile->status_label }}</span>
                                @if($requestForFile->canDownload())
                                    <a href="{{ route('admin.download.show', $requestForFile) }}" class="btn btn-sm btn-success">
                                        <i class="fas fa-download"></i> Unduh
                                    </a>
                                @else
                                    <a href="{{ route('admin.requests.show', $requestForFile) }}" class="btn btn-sm btn-outline">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                @endif
                            @else
                                <span class="badge badge-active">Akses Metadata</span>
                                <a href="{{ route('admin.requests.create') }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-file-signature"></i> Minta Data
                                </a>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="empty-state">
                <i class="fas fa-folder-open"></i>
                <div style="font-weight:700; color:#111827; margin-bottom:6px;">Belum ada dataset yang diberikan akses</div>
                <div style="font-size:13px; max-width:520px; margin:0 auto 14px;">
                    Super Admin perlu memberi izin dataset terlebih dahulu sebelum Anda dapat mengajukan permintaan data dan melampirkan NDA.
                </div>
                <a href="{{ route('admin.requests.create') }}" class="btn btn-primary">
                    <i class="fas fa-file-signature"></i> Cek Form Permintaan Izin
                </a>
            </div>
        @endif
    </div>

    <div>
        <div class="card">
            <div class="card-header">
                <span class="card-title"><i class="fas fa-file-contract"></i> Permintaan Terbaru</span>
                <a href="{{ route('admin.requests.index') }}" class="btn btn-sm btn-outline">Lihat Semua</a>
            </div>

            <div class="quick-list">
                @forelse($recentRequests as $req)
                    <div class="quick-list__item">
                        <div>
                            <strong style="font-size:13px;">{{ $req->dataFile->judul ?? 'Dataset tidak tersedia' }}</strong>
                            <div style="font-size:11px; color:#6b7280; margin-top:3px;">{{ $req->created_at->diffForHumans() }}</div>
                        </div>
                        <div style="display:flex; gap:8px; align-items:center;">
                            <span class="badge badge-{{ $req->status }}">{{ $req->status_label }}</span>
                            @if($req->canDownload())
                                <a href="{{ route('admin.download.show', $req) }}" class="btn btn-sm btn-success" title="Unduh">
                                    <i class="fas fa-download"></i>
                                </a>
                            @endif
                        </div>
                    </div>
                @empty
                    <div class="empty-state" style="padding:18px;">
                        <i class="fas fa-file-circle-plus"></i>
                        <div style="font-size:13px;">Belum ada permintaan data.</div>
                    </div>
                @endforelse
            </div>
        </div>

        <div class="card">
            <div class="card-header"><span class="card-title"><i class="fas fa-route"></i> Alur Akses</span></div>
            <div class="quick-list" style="font-size:13px;">
                <div class="quick-list__item"><span>1. Dataset diberi izin oleh Super Admin</span><i class="fas fa-user-shield" style="color:#155e75;"></i></div>
                <div class="quick-list__item"><span>2. Ajukan permintaan dan lampirkan NDA</span><i class="fas fa-file-pdf" style="color:#be123c;"></i></div>
                <div class="quick-list__item"><span>3. Tunggu review dan persetujuan</span><i class="fas fa-clock" style="color:#d97706;"></i></div>
                <div class="quick-list__item"><span>4. Unduh setelah verifikasi captcha</span><i class="fas fa-download" style="color:#15803d;"></i></div>
            </div>
            <a href="{{ route('admin.requests.create') }}" class="btn btn-primary" style="width:100%; justify-content:center; margin-top:16px;">
                <i class="fas fa-plus"></i> Ajukan Permintaan
            </a>
        </div>
    </div>
</div>
@endsection
