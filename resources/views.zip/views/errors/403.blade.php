<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>403 - Akses Ditolak</title>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #1e3a5f; min-height: 100vh; display: flex; align-items: center; justify-content: center; color: #fff; }
        .box { text-align: center; padding: 40px; }
        .icon { font-size: 80px; margin-bottom: 20px; }
        h1 { font-size: 28px; margin-bottom: 10px; }
        p { color: rgba(255,255,255,.7); margin-bottom: 24px; }
        a { background: #fff; color: #1e3a5f; padding: 10px 24px; border-radius: 6px; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
    <div class="box">
        <div class="icon">🔒</div>
        <h1>403 — Akses Ditolak</h1>
        <p>Anda tidak memiliki izin untuk mengakses halaman ini.<br>
        Aktivitas ini telah dicatat dalam sistem audit.</p>
        <a href="{{ url()->previous() }}">← Kembali</a>
    </div>
</body>
</html>
