<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Data Keluarga</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', sans-serif; background: #1e3a5f; min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-wrapper { width: 100%; max-width: 420px; padding: 16px; }
        .login-header { text-align: center; margin-bottom: 24px; color: #fff; }
        .login-header .logo { font-size: 40px; margin-bottom: 12px; }
        .login-header h1 { font-size: 20px; font-weight: 700; }
        .login-header p { font-size: 12px; opacity: .7; margin-top: 4px; }
        .login-card { background: #fff; border-radius: 12px; padding: 32px; box-shadow: 0 20px 60px rgba(0,0,0,.3); }
        .login-card h2 { font-size: 18px; font-weight: 600; margin-bottom: 24px; color: #1e3a5f; }
        .form-group { margin-bottom: 16px; }
        .form-label { display: block; font-size: 13px; font-weight: 500; margin-bottom: 5px; color: #343a40; }
        .form-control { width: 100%; padding: 10px 14px; border: 1px solid #dee2e6; border-radius: 6px; font-size: 14px; }
        .form-control:focus { outline: none; border-color: #2d5a8e; box-shadow: 0 0 0 3px rgba(45,90,142,.15); }
        .btn-login { width: 100%; padding: 12px; background: #1e3a5f; color: #fff; border: none; border-radius: 6px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 8px; }
        .btn-login:hover { background: #2d5a8e; }
        .error-msg { background: #f8d7da; color: #842029; padding: 10px 14px; border-radius: 6px; font-size: 13px; margin-bottom: 16px; border: 1px solid #f1aeb5; }
        .pdp-notice { margin-top: 16px; padding: 12px; background: #fff3cd; border-radius: 6px; font-size: 11px; color: #664d03; border: 1px solid #ffda6a; }
        .footer-note { text-align: center; color: rgba(255,255,255,.5); font-size: 11px; margin-top: 20px; }
        .checkbox-wrap { display: flex; align-items: center; gap: 8px; font-size: 13px; }
        .checkbox-wrap input { cursor: pointer; }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-header">
            <div class="logo">🏛️</div>
            <h1>Sistem Data Keluarga</h1>
            <p>Portal Manajemen Data Kependudukan</p>
        </div>

        <div class="login-card">
            <h2>🔐 Masuk ke Sistem</h2>

            @if($errors->any())
                <div class="error-msg">
                    @foreach($errors->all() as $error)
                        <div>{{ $error }}</div>
                    @endforeach
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="{{ old('username') }}" required autofocus placeholder="username">
                </div>
                <div class="form-group">
                    <label class="form-label">Kata Sandi</label>
                    <input type="password" name="password" class="form-control" required placeholder="••••••••••••">
                </div>
                <div class="form-group">
                    <label class="checkbox-wrap">
                        <input type="checkbox" name="remember"> Ingat saya (30 hari)
                    </label>
                </div>
                <button type="submit" class="btn-login">Masuk ke Sistem</button>
            </form>

            <div class="pdp-notice">
                <strong>⚠️ Perhatian Keamanan Data (UU PDP No.27/2022):</strong><br>
                Sistem ini mengelola data pribadi yang dilindungi undang-undang. Seluruh aktivitas Anda dipantau dan dicatat. Akses tidak sah merupakan pelanggaran hukum.
            </div>
        </div>

        <div class="footer-note">
            © {{ date('Y') }} Sistem Data Keluarga &mdash; Dilindungi UU PDP
        </div>
    </div>
</body>
</html>
