@extends('layouts.app')
@section('page-title', 'Dashboard Super Admin')

@section('content')
<div class="pdp-notice">
    <strong>🛡️ UU PDP No.27/2022:</strong> Sebagai pengendali data, Anda bertanggung jawab memastikan keamanan dan kepatuhan pemrosesan seluruh data pribadi dalam sistem ini.
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon blue"><i class="fas fa-database"></i></div>
        <div>
            <div class="stat-num">{{ $stats['total_files'] }}</div>
            <div class="stat-label">Total File Data</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon orange"><i class="fas fa-clock"></i></div>
        <div>
            <div class="stat-num">{{ $stats['pending_requests'] }}</div>
            <div class="stat-label">Permintaan Pending</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon green"><i class="fas fa-users"></i></div>
        <div>
            <div class="stat-num">{{ $stats['total_admins'] }}</div>
            <div class="stat-label">Total Admin</div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-icon red"><i class="fas fa-download"></i></div>
        <div>
            <div class="stat-num">{{ $stats['downloads_today'] }}</div>
            <div class="stat-label">Download Hari Ini</div>
        </div>
    </div>
</div>

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
    <!-- Permintaan terbaru -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">Permintaan Data Terbaru</span>
            <a href="{{ route('superadmin.requests.index', ['status' => 'pending']) }}" class="btn btn-sm btn-outline">Lihat Semua</a>
        </div>
        @forelse($recentRequests as $req)
        <div style="padding:10px 0; border-bottom:1px solid #f0f0f0; font-size:13px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <strong>{{ $req->user->name }}</strong>
                <span class="badge badge-{{ $req->status }}">{{ $req->status_label }}</span>
            </div>
            <div style="color:#6c757d; margin-top:3px;">{{ $req->dataFile->judul }}</div>
            <div style="color:#adb5bd; font-size:11px;">{{ $req->created_at->diffForHumans() }}</div>
        </div>
        @empty
        <p style="color:#6c757d; font-size:13px;">Belum ada permintaan.</p>
        @endforelse
    </div>

    <!-- Aktivitas terakhir -->
    <div class="card">
        <div class="card-header">
            <span class="card-title">Aktivitas Terkini</span>
            <a href="{{ route('superadmin.audit.index') }}" class="btn btn-sm btn-outline">Audit Log</a>
        </div>
        @forelse($recentActivity as $log)
        <div style="padding:8px 0; border-bottom:1px solid #f0f0f0; font-size:12px; display:flex; gap:10px;">
            <div style="color:#1e3a5f; font-size:18px;">
                @switch($log->action)
                    @case('login') 🔐 @break
                    @case('file_upload') 📤 @break
                    @case('file_download') 📥 @break
                    @case('request_approve') ✅ @break
                    @default 📋
                @endswitch
            </div>
            <div>
                <div><strong>{{ $log->user->name ?? 'Sistem' }}</strong> — {{ $log->action }}</div>
                <div style="color:#adb5bd;">{{ $log->occurred_at->format('d/m H:i') }} &bull; {{ $log->ip_address }}</div>
            </div>
        </div>
        @empty
        <p style="color:#6c757d; font-size:13px;">Belum ada aktivitas.</p>
        @endforelse
    </div>
</div>
@endsection
