@extends('layouts.app')
@section('page-title', 'Edit Pengguna')

@section('content')
<div style="max-width:700px; margin:0 auto;">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-edit"></i> Edit: {{ $user->name }}</span>
            <a href="{{ route('superadmin.users.index') }}" class="btn btn-sm btn-outline">← Kembali</a>
        </div>

        <form action="{{ route('superadmin.users.update', $user) }}" method="POST">
            @csrf @method('PUT')

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="form-group">
                    <label class="form-label">Nama Lengkap <span class="required">*</span></label>
                    <input type="text" name="name" class="form-control" value="{{ old('name', $user->name) }}" required>
                    @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="form-group">
                    <label class="form-label">Username <span class="required">*</span></label>
                    <input type="text" name="username" class="form-control" value="{{ old('username', $user->username) }}" required>
                    @error('username')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    <div class="form-text">Username digunakan untuk login.</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-control" value="{{ $user->email }}" disabled style="background:#f8f9fa; color:#6c757d;">
                    <div class="form-text">Email tidak dapat diubah.</div>
                </div>
                <div class="form-group">
                    <label class="form-label">Instansi <span class="required">*</span></label>
                    <input type="text" name="instansi" class="form-control" value="{{ old('instansi', $user->instansi) }}" required>
                    @error('instansi')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="form-group">
                    <label class="form-label">Jabatan <span class="required">*</span></label>
                    <input type="text" name="jabatan" class="form-control" value="{{ old('jabatan', $user->jabatan) }}" required>
                    @error('jabatan')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="form-group">
                    <label class="form-label">Nomor Telepon</label>
                    <input type="text" name="phone" class="form-control" value="{{ old('phone', $user->phone) }}">
                </div>
                <div class="form-group">
                    <label class="form-label">Role <span class="required">*</span></label>
                    <select name="role" class="form-control" {{ $user->id === auth()->id() ? 'disabled' : '' }}>
                        <option value="admin"       {{ $user->hasRole('admin')       ? 'selected':'' }}>Admin</option>
                        <option value="super_admin" {{ $user->hasRole('super_admin') ? 'selected':'' }}>Super Admin</option>
                    </select>
                    @if($user->id === auth()->id())
                        <input type="hidden" name="role" value="{{ $user->getRoleNames()->first() }}">
                        <div class="form-text">Role Anda sendiri tidak dapat diubah.</div>
                    @endif
                </div>
            </div>

            <div style="display:flex; gap:10px; margin-top:16px; padding-top:16px; border-top:1px solid #dee2e6;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Perubahan</button>
                <a href="{{ route('superadmin.users.index') }}" class="btn btn-outline">Batal</a>
            </div>
        </form>
    </div>

    <!-- Reset Password -->
    <div class="card" style="border-left:4px solid #ffc107;">
        <div class="card-header">
            <span class="card-title"><i class="fas fa-key"></i> Reset Kata Sandi</span>
        </div>
        <form action="{{ route('superadmin.users.reset-password', $user) }}" method="POST">
            @csrf
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div class="form-group">
                    <label class="form-label">Kata Sandi Baru <span class="required">*</span></label>
                    <input type="password" name="password" class="form-control" required>
                    <div class="form-text">Min 12 karakter, kombinasi huruf besar/kecil, angka, dan karakter khusus.</div>
                    @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="form-group">
                    <label class="form-label">Konfirmasi <span class="required">*</span></label>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>
            </div>
            <button type="submit" class="btn btn-warning" onclick="return confirm('Reset kata sandi pengguna ini?')">
                <i class="fas fa-key"></i> Reset Kata Sandi
            </button>
        </form>
    </div>

    <!-- Info akun -->
    <div class="card" style="font-size:12px;">
        <div class="card-header"><span class="card-title">ℹ️ Info Akun</span></div>
        <table style="width:100%; border:none; font-size:12px;">
            <tr><td style="border:none; color:#6c757d; padding:4px 0; width:160px;">Username</td><td style="border:none; font-family:monospace;">{{ $user->username }}</td></tr>
            <tr><td style="border:none; color:#6c757d; padding:4px 0; width:160px;">Dibuat</td><td style="border:none;">{{ $user->created_at->format('d/m/Y H:i') }}</td></tr>
            <tr><td style="border:none; color:#6c757d; padding:4px 0;">Login Terakhir</td><td style="border:none;">{{ $user->last_login_at?->format('d/m/Y H:i') ?? '—' }}</td></tr>
            <tr><td style="border:none; color:#6c757d; padding:4px 0;">IP Terakhir</td><td style="border:none; font-family:monospace;">{{ $user->last_login_ip ?? '—' }}</td></tr>
            <tr><td style="border:none; color:#6c757d; padding:4px 0;">Gagal Login</td><td style="border:none;">{{ $user->failed_login_attempts }}×</td></tr>
            <tr><td style="border:none; color:#6c757d; padding:4px 0;">Terkunci Sampai</td><td style="border:none;">{{ $user->locked_until?->format('d/m/Y H:i') ?? '—' }}</td></tr>
        </table>
    </div>
</div>
@endsection
