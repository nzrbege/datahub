@extends('layouts.app')
@section('page-title', 'Tambah Pengguna')

@section('content')
<div class="card" style="max-width:700px; margin:0 auto;">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-user-plus"></i> Tambah Pengguna Baru</span>
        <a href="{{ route('superadmin.users.index') }}" class="btn btn-sm btn-outline">← Kembali</a>
    </div>

    <div class="pdp-notice">
        <strong>UU PDP Pasal 50:</strong> Setiap penambahan pengguna wajib berdasarkan kebutuhan nyata. Prinsip <em>need-to-know</em> — berikan akses seminimal mungkin sesuai tugas.
    </div>

    <form action="{{ route('superadmin.users.store') }}" method="POST">
        @csrf

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
            <div class="form-group">
                <label class="form-label">Nama Lengkap <span class="required">*</span></label>
                <input type="text" name="name" class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                    value="{{ old('name') }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="form-group">
                <label class="form-label">Username <span class="required">*</span></label>
                <input type="text" name="username" class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}"
                    value="{{ old('username') }}" required placeholder="username">
                @error('username')<div class="invalid-feedback">{{ $message }}</div>@enderror
                <div class="form-text">Gunakan huruf, angka, dash, atau underscore.</div>
            </div>

            <div class="form-group">
                <label class="form-label">Email <span class="required">*</span></label>
                <input type="email" name="email" class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                    value="{{ old('email') }}" required placeholder="nama@instansi.go.id">
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="form-group">
                <label class="form-label">Instansi / Lembaga <span class="required">*</span></label>
                <input type="text" name="instansi" class="form-control {{ $errors->has('instansi') ? 'is-invalid' : '' }}"
                    value="{{ old('instansi') }}" required>
                @error('instansi')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="form-group">
                <label class="form-label">Jabatan <span class="required">*</span></label>
                <input type="text" name="jabatan" class="form-control {{ $errors->has('jabatan') ? 'is-invalid' : '' }}"
                    value="{{ old('jabatan') }}" required>
                @error('jabatan')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>

            <div class="form-group">
                <label class="form-label">Nomor Telepon</label>
                <input type="text" name="phone" class="form-control" value="{{ old('phone') }}" placeholder="+62...">
            </div>

            <div class="form-group">
                <label class="form-label">Role <span class="required">*</span></label>
                <select name="role" class="form-control" required>
                    <option value="admin" {{ old('role')=='admin' ? 'selected':'' }}>Admin</option>
                    <option value="super_admin" {{ old('role')=='super_admin' ? 'selected':'' }}>Super Admin</option>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Kata Sandi <span class="required">*</span></label>
                <input type="password" name="password" id="password"
                    class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}" required>
                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                <div class="form-text">Min 12 karakter: huruf besar, kecil, angka & karakter khusus (@$!%*?&#)</div>
            </div>

            <div class="form-group">
                <label class="form-label">Konfirmasi Kata Sandi <span class="required">*</span></label>
                <input type="password" name="password_confirmation" class="form-control" required>
            </div>
        </div>

        <!-- Indikator kekuatan password -->
        <div id="pwStrength" style="margin-bottom:16px; font-size:12px; display:none;">
            <div style="height:6px; background:#dee2e6; border-radius:3px; margin-bottom:4px;">
                <div id="pwBar" style="height:100%; border-radius:3px; transition:width .3s; width:0;"></div>
            </div>
            <span id="pwLabel" style="color:#6c757d;"></span>
        </div>

        <div style="display:flex; gap:10px; padding-top:8px; border-top:1px solid #dee2e6; margin-top:8px;">
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-user-plus"></i> Tambah Pengguna
            </button>
            <a href="{{ route('superadmin.users.index') }}" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

@push('scripts')
<script>
const pw = document.getElementById('password');
const bar = document.getElementById('pwBar');
const lbl = document.getElementById('pwLabel');
const wrap = document.getElementById('pwStrength');

pw.addEventListener('input', function() {
    const v = this.value;
    if (!v) { wrap.style.display='none'; return; }
    wrap.style.display='block';
    let score = 0;
    if (v.length >= 12) score++;
    if (/[A-Z]/.test(v)) score++;
    if (/[a-z]/.test(v)) score++;
    if (/\d/.test(v)) score++;
    if (/[@$!%*?&#]/.test(v)) score++;
    const pct = (score/5)*100;
    bar.style.width = pct+'%';
    const colors = ['#dc3545','#fd7e14','#ffc107','#20c997','#198754'];
    const labels = ['Sangat Lemah','Lemah','Cukup','Kuat','Sangat Kuat'];
    bar.style.background = colors[score-1] || '#dc3545';
    lbl.textContent = labels[score-1] || 'Sangat Lemah';
    lbl.style.color = colors[score-1] || '#dc3545';
});
</script>
@endpush
@endsection
