@extends('layouts.app')
@section('page-title', 'Manajemen Pengguna')

@section('content')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-users"></i> Daftar Pengguna Sistem</span>
        <a href="{{ route('superadmin.users.create') }}" class="btn btn-primary btn-sm">
            <i class="fas fa-user-plus"></i> Tambah Pengguna
        </a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Instansi</th>
                    <th>Jabatan</th>
                    <th>Role</th>
                    <th>Login Terakhir</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr style="{{ $user->trashed() ? 'opacity:.5;' : '' }}">
                    <td style="color:#adb5bd;">{{ $user->id }}</td>
                    <td>
                        <strong>{{ $user->name }}</strong>
                        @if($user->trashed())
                            <span class="badge badge-inactive">Dihapus</span>
                        @endif
                        @if($user->isLocked())
                            <span class="badge" style="background:#fce4ec; color:#880e4f;">Terkunci</span>
                        @endif
                    </td>
                    <td style="font-size:12px; font-family:monospace;">{{ $user->username ?? '-' }}</td>
                    <td style="font-size:12px;">{{ $user->email }}</td>
                    <td style="font-size:12px;">{{ $user->instansi ?? '—' }}</td>
                    <td style="font-size:12px;">{{ $user->jabatan ?? '—' }}</td>
                    <td>
                        @foreach($user->getRoleNames() as $role)
                            <span class="badge {{ $role === 'super_admin' ? 'badge-sa' : 'badge-admin' }}">
                                {{ $role === 'super_admin' ? 'Super Admin' : 'Admin' }}
                            </span>
                        @endforeach
                    </td>
                    <td style="font-size:11px; color:#6c757d;">
                        @if($user->last_login_at)
                            {{ $user->last_login_at->format('d/m/Y H:i') }}
                            <div style="color:#adb5bd;">{{ $user->last_login_ip }}</div>
                        @else
                            <span style="color:#adb5bd;">Belum pernah</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge {{ $user->is_active ? 'badge-active' : 'badge-inactive' }}">
                            {{ $user->is_active ? 'Aktif' : 'Nonaktif' }}
                        </span>
                    </td>
                    <td>
                        @if(!$user->trashed())
                        <div style="display:flex; gap:4px; flex-wrap:wrap;">
                            <a href="{{ route('superadmin.users.edit', $user) }}" class="btn btn-sm btn-outline" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            @if($user->id !== auth()->id())
                            <form action="{{ route('superadmin.users.toggle-active', $user) }}" method="POST">
                                @csrf @method('PATCH')
                                <button type="submit" class="btn btn-sm {{ $user->is_active ? 'btn-warning' : 'btn-success' }}"
                                    title="{{ $user->is_active ? 'Nonaktifkan' : 'Aktifkan' }}">
                                    <i class="fas fa-{{ $user->is_active ? 'ban' : 'check' }}"></i>
                                </button>
                            </form>
                            @endif
                        </div>
                        @endif
                    </td>
                </tr>
                @empty
                <tr><td colspan="10" style="text-align:center; color:#adb5bd; padding:32px;">Belum ada pengguna.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;">{{ $users->links() }}</div>
</div>

<div class="pdp-notice">
    <strong>🔐 UU PDP Pasal 50-51:</strong> Setiap perubahan data pengguna, pemberian/pencabutan akses tercatat dalam audit log. Hapus akun pengguna yang sudah tidak aktif untuk meminimalisir risiko kebocoran data.
</div>
@endsection
