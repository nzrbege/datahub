@extends('layouts.app')
@section('page-title', 'Log Download')

@section('content')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-download"></i> Log Download File</span>
        <div style="display:flex; gap:8px; align-items:center;">
            <a href="{{ route('superadmin.audit.downloads.export') }}" class="btn btn-sm btn-primary">
                <i class="fas fa-file-export"></i> Export CSV
            </a>
            <a href="{{ route('superadmin.audit.index') }}" class="btn btn-sm btn-outline">Log Aktivitas</a>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Waktu</th>
                    <th>Pengguna</th>
                    <th>File</th>
                    <th>IP Address</th>
                    <th>Captcha</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td style="font-size:11px; white-space:nowrap; color:#6c757d;">
                        {{ $log->downloaded_at->format('d/m/Y') }}<br>
                        <strong>{{ $log->downloaded_at->format('H:i:s') }}</strong>
                    </td>
                    <td style="font-size:12px;">
                        <strong>{{ $log->user->name ?? '—' }}</strong>
                        <div style="color:#adb5bd; font-size:10px;">{{ $log->user->instansi ?? '' }}</div>
                    </td>
                    <td style="font-size:12px;">
                        {{ $log->dataFile->judul ?? '—' }}
                        <div style="color:#adb5bd; font-size:10px;">{{ $log->dataFile->original_filename ?? '' }}</div>
                    </td>
                    <td style="font-family:monospace; font-size:11px;">{{ $log->ip_address }}</td>
                    <td style="text-align:center; font-size:16px;">
                        {{ $log->captcha_passed ? '✅' : '❌' }}
                    </td>
                    <td>
                        <span class="badge {{ $log->status === 'success' ? 'badge-approved' : ($log->status === 'blocked' ? 'badge-rejected' : 'badge-inactive') }}">
                            {{ $log->status }}
                        </span>
                    </td>
                    <td style="font-size:11px; color:#6c757d;">{{ $log->keterangan ?? '—' }}</td>
                </tr>
                @empty
                <tr><td colspan="7" style="text-align:center; color:#adb5bd; padding:24px;">Belum ada log download.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;">{{ $logs->links() }}</div>
</div>
@endsection
