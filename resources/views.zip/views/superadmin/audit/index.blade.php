@extends('layouts.app')
@section('page-title', 'Log Aktivitas')

@section('content')
<div class="pdp-notice">
    <strong>📋 UU PDP Pasal 47:</strong> Log ini merupakan catatan wajib seluruh aktivitas pemrosesan data pribadi. Log disimpan permanen dan tidak dapat dihapus secara manual.
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-shield-alt"></i> Log Aktivitas Pemrosesan Data Pribadi</span>
        <div style="display:flex; gap:8px; align-items:center;">
            <a href="{{ route('superadmin.audit.export', request()->query()) }}" class="btn btn-sm btn-primary">
                <i class="fas fa-file-export"></i> Export CSV
            </a>
            <a href="{{ route('superadmin.audit.downloads') }}" class="btn btn-sm btn-outline">
                <i class="fas fa-download"></i> Log Download
            </a>
        </div>
    </div>

    <!-- Filter -->
    <form method="GET" style="display:flex; gap:10px; margin-bottom:16px; flex-wrap:wrap; align-items:flex-end;">
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:11px;">Aksi</label>
            <select name="action" class="form-control" style="width:auto; font-size:12px; padding:6px 10px;">
                <option value="">Semua Aksi</option>
                @foreach(['login','logout','login_failed','file_upload','file_download','file_view','file_delete','request_create','request_approve','request_reject','request_revoke','nda_view','nda_download','permission_grant','user_create','user_update'] as $act)
                <option value="{{ $act }}" {{ request('action')==$act ? 'selected':'' }}>{{ $act }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:11px;">Dari Tanggal</label>
            <input type="date" name="date_from" class="form-control" style="width:auto; font-size:12px;" value="{{ request('date_from') }}">
        </div>
        <div class="form-group" style="margin-bottom:0;">
            <label class="form-label" style="font-size:11px;">Sampai</label>
            <input type="date" name="date_to" class="form-control" style="width:auto; font-size:12px;" value="{{ request('date_to') }}">
        </div>
        <button type="submit" class="btn btn-primary btn-sm">Filter</button>
        <a href="{{ route('superadmin.audit.index') }}" class="btn btn-outline btn-sm">Reset</a>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Waktu</th>
                    <th>Pengguna</th>
                    <th>Aksi</th>
                    <th>Resource</th>
                    <th>IP Address</th>
                    <th>Dasar Hukum</th>
                    <th>Tujuan</th>
                </tr>
            </thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td style="font-size:11px; white-space:nowrap; color:#6c757d;">
                        {{ $log->occurred_at->format('d/m/Y') }}<br>
                        <strong>{{ $log->occurred_at->format('H:i:s') }}</strong>
                    </td>
                    <td style="font-size:12px;">
                        <strong>{{ $log->user->name ?? 'Sistem' }}</strong>
                        <div style="color:#adb5bd; font-size:10px;">ID: {{ $log->user_id }}</div>
                    </td>
                    <td>
                        @php
                            $actionColors = [
                                'login' => '#d1e7dd', 'logout' => '#e2e3e5',
                                'login_failed' => '#f8d7da', 'file_download' => '#cff4fc',
                                'file_upload' => '#d1e7dd', 'file_delete' => '#f8d7da',
                                'nda_view' => '#e3f2fd', 'nda_download' => '#cff4fc',
                                'request_approve' => '#d1e7dd', 'request_reject' => '#f8d7da',
                                'permission_grant' => '#d1e7dd', 'permission_revoke' => '#fff3cd',
                            ];
                            $bg = $actionColors[$log->action] ?? '#f0f0f0';
                        @endphp
                        <span style="background:{{ $bg }}; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600;">
                            {{ $log->action }}
                        </span>
                    </td>
                    <td style="font-size:11px; color:#6c757d;">
                        @if($log->resource_type)
                            {{ $log->resource_type }} #{{ $log->resource_id }}
                        @else
                            —
                        @endif
                    </td>
                    <td style="font-family:monospace; font-size:11px;">{{ $log->ip_address }}</td>
                    <td style="font-size:11px; color:#6c757d; max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="{{ $log->dasar_hukum }}">
                        {{ $log->dasar_hukum ?? '—' }}
                    </td>
                    <td style="font-size:11px; color:#6c757d; max-width:150px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" title="{{ $log->tujuan }}">
                        {{ $log->tujuan ?? '—' }}
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" style="text-align:center; color:#adb5bd; padding:24px;">Tidak ada log aktivitas.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;">{{ $logs->links() }}</div>
</div>
@endsection
