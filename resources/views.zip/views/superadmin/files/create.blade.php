@extends('layouts.app')
@section('page-title', 'Unggah File Data')

@section('content')
<div class="pdp-notice">
    <strong>⚠️ UU PDP Pasal 35:</strong> File yang diunggah akan dienkripsi dengan AES-256. Tentukan dengan cermat admin mana yang boleh mengakses data ini. Hash SHA-256 dicatat untuk verifikasi integritas.
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-upload"></i> Unggah File Data Keluarga</span>
        <a href="{{ route('superadmin.files.index') }}" class="btn btn-sm btn-outline"><i class="fas fa-arrow-left"></i> Kembali</a>
    </div>

    <form action="{{ route('superadmin.files.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
            <div>
                <div class="form-group">
                    <label class="form-label">Judul Data <span class="required">*</span></label>
                    <input type="text" name="judul" class="form-control" value="{{ old('judul') }}" placeholder="mis: Dataset Keluarga Kecamatan Prambanan 2024">
                </div>
                <div class="form-group">
                    <label class="form-label">Jenis Dataset <span class="required">*</span></label>
                    <select name="kategori" class="form-control">
                        <option value="">Pilih Jenis Dataset</option>
                        <option value="DATASET_KELUARGA" {{ old('kategori')=='DATASET_KELUARGA'?'selected':'' }}>Dataset Keluarga</option>
                        <option value="DATASET_ANGGOTA_KELUARGA" {{ old('kategori')=='DATASET_ANGGOTA_KELUARGA'?'selected':'' }}>Dataset Anggota Keluarga</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Periode Data</label>
                    <input type="text" name="tahun_data" class="form-control" value="{{ old('tahun_data', date('Y')) }}" placeholder="mis: 2024 atau 2024-06">
                    <div class="form-text">Isi tahun saja atau tahun-bulan.</div>
                </div>
            </div>

            <div>
                <div class="form-group">
                    <label class="form-label">Deskripsi</label>
                    <textarea name="deskripsi" class="form-control" rows="3" placeholder="Deskripsi singkat tentang isi dan tujuan data...">{{ old('deskripsi') }}</textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">File Data <span class="required">*</span></label>
                    <input type="file" name="file" class="form-control" accept=".xlsx,.csv,.zip" id="fileInput">
                    <div class="form-text">Format: XLSX, CSV, ZIP. Maks: 50MB. File akan <strong>dienkripsi AES-256</strong> secara otomatis.</div>
                    <div id="fileInfo" style="margin-top:6px; font-size:12px; color:#0f5132; display:none;"></div>
                </div>
            </div>
        </div>

        <!-- Permission Section -->
        <div style="margin-top:8px;">
            <div style="font-size:14px; font-weight:600; margin-bottom:10px; padding-bottom:8px; border-bottom:1px solid #dee2e6;">
                🔒 Izin Akses Admin
            </div>
            <div class="pdp-notice" style="margin-bottom:12px;">
                Pilih admin yang diizinkan mengakses file ini. Admin yang tidak dipilih <strong>tidak akan bisa</strong> melihat atau mengunduh file ini sama sekali.
            </div>

            @if($admins->isEmpty())
                <div class="alert alert-warning"><i class="fas fa-exclamation-triangle"></i> Belum ada admin yang terdaftar. Tambah admin terlebih dahulu.</div>
            @else
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(280px, 1fr)); gap:10px;">
                    @foreach($admins as $admin)
                    <label style="display:flex; align-items:center; gap:10px; padding:12px; border:1px solid #dee2e6; border-radius:6px; cursor:pointer; font-size:13px; transition:border .15s;" onmouseover="this.style.borderColor='#1e3a5f'" onmouseout="this.style.borderColor='#dee2e6'">
                        <input type="checkbox" name="admin_ids[]" value="{{ $admin->id }}" {{ in_array($admin->id, old('admin_ids', [])) ? 'checked' : '' }} style="cursor:pointer;">
                        <div>
                            <strong>{{ $admin->name }}</strong>
                            <div style="color:#6c757d; font-size:11px;">{{ $admin->instansi }} &bull; {{ $admin->jabatan }}</div>
                        </div>
                    </label>
                    @endforeach
                </div>
                <div class="form-text" style="margin-top:8px;">Tidak memilih berarti file hanya bisa diakses Super Admin.</div>
            @endif
        </div>

        <div style="margin-top:24px; padding-top:16px; border-top:1px solid #dee2e6; display:flex; gap:10px;">
            <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Unggah & Enkripsi File</button>
            <a href="{{ route('superadmin.files.index') }}" class="btn btn-outline">Batal</a>
        </div>
    </form>
</div>

@push('scripts')
<script>
document.getElementById('fileInput').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const size = (file.size / 1024 / 1024).toFixed(2);
        document.getElementById('fileInfo').style.display = 'block';
        document.getElementById('fileInfo').innerHTML = `✅ ${file.name} (${size} MB) — akan dienkripsi sebelum disimpan`;
    }
});
</script>
@endpush
@endsection
