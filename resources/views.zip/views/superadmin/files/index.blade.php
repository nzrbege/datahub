@extends('layouts.app')
@section('page-title', 'Manajemen File Data')

@section('content')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-database"></i> Daftar File Data Keluarga</span>
        <a href="{{ route('superadmin.files.create') }}" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Unggah File Baru
        </a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Judul</th>
                    <th>Jenis Dataset</th>
                    <th>Periode Data</th>
                    <th>Ukuran</th>
                    <th>Diizinkan</th>
                    <th>Diunggah</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($files as $file)
                <tr>
                    <td style="color:#adb5bd;">{{ $file->id }}</td>
                    <td>
                        <strong>{{ $file->judul }}</strong>
                        <div style="font-size:11px; color:#adb5bd;">
                            <i class="fas fa-lock" style="color:#198754;" title="Terenkripsi AES-256"></i>
                            {{ $file->original_filename }}
                        </div>
                    </td>
                    <td><span class="badge" style="background:#e3f2fd; color:#1565c0;">{{ $file->kategori_label }}</span></td>
                    <td>{{ $file->tahun_data ?? '—' }}</td>
                    <td>{{ $file->file_size_human }}</td>
                    <td>
                        @if($file->allowed_users_count > 0)
                            <span style="color:#0f5132; font-weight:600;">{{ $file->allowed_users_count }} admin</span>
                        @else
                            <span style="color:#adb5bd; font-size:12px;">Super Admin only</span>
                        @endif
                    </td>
                    <td style="font-size:12px; color:#6c757d;">
                        {{ $file->uploader->name ?? '—' }}<br>
                        {{ $file->created_at->format('d/m/Y') }}
                    </td>
                    <td>
                        @if($file->is_active)
                            <span class="badge badge-active">Aktif</span>
                        @else
                            <span class="badge badge-inactive">Nonaktif</span>
                        @endif
                    </td>
                    <td>
                        <div style="display:flex; gap:6px;">
                            <a href="{{ route('superadmin.files.show', $file) }}" class="btn btn-sm btn-outline" title="Detail">
                                <i class="fas fa-eye"></i>
                            </a>
                            <form action="{{ route('superadmin.files.destroy', $file) }}" method="POST"
                                onsubmit="return confirm('Hapus file ini? Data tidak dapat dipulihkan.')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" title="Hapus">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="9" style="text-align:center; color:#adb5bd; padding:32px;">
                    Belum ada file data yang diunggah.
                    <a href="{{ route('superadmin.files.create') }}">Unggah sekarang</a>
                </td></tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div style="margin-top:16px;">{{ $files->links() }}</div>
</div>

<div class="pdp-notice">
    <strong>🛡️ Keamanan:</strong> Semua file tersimpan dalam format terenkripsi AES-256 di storage private. File tidak dapat diakses langsung via URL. Setiap akses dan unduhan tercatat dalam audit log (UU PDP Pasal 47).
</div>
@endsection
