@extends('layouts.app')
@section('page-title', 'Detail File Data')

@section('content')
<div style="display:grid; grid-template-columns:2fr 1fr; gap:20px; align-items:start;">

    <!-- Kiri: Info + Permissions -->
    <div>
        <div class="card">
            <div class="card-header">
                <span class="card-title"><i class="fas fa-database"></i> {{ $dataFile->judul }}</span>
                <a href="{{ route('superadmin.files.index') }}" class="btn btn-sm btn-outline">← Kembali</a>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px; font-size:13px; margin-bottom:20px;">
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">File Asli</div>
                    <div><i class="fas fa-file" style="color:#1e3a5f;"></i> {{ $dataFile->original_filename }}</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Ukuran</div>
                    <div>{{ $dataFile->file_size_human }}</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Jenis Dataset</div>
                    <div>{{ $dataFile->kategori_label }}</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Periode Data</div>
                    <div>{{ $dataFile->tahun_data ?? '—' }}</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Enkripsi</div>
                    <div><i class="fas fa-lock" style="color:#198754;"></i> AES-256-CBC + HMAC-SHA256</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Hash Integritas</div>
                    <div style="font-family:monospace; font-size:11px; color:#6c757d; word-break:break-all;">{{ substr($dataFile->file_hash, 0, 32) }}…</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Diunggah Oleh</div>
                    <div>{{ $dataFile->uploader->name ?? '—' }}</div>
                </div>
                <div>
                    <div style="color:#6c757d; font-size:11px; text-transform:uppercase; margin-bottom:2px;">Tanggal Upload</div>
                    <div>{{ $dataFile->created_at->format('d/m/Y H:i') }}</div>
                </div>
            </div>

            @if($dataFile->deskripsi)
            <div style="background:#f8f9fa; padding:12px; border-radius:6px; font-size:13px; line-height:1.6; margin-bottom:16px;">
                {{ $dataFile->deskripsi }}
            </div>
            @endif
        </div>

        <!-- Kelola Izin Akses -->
        <div class="card">
            <div class="card-header">
                <span class="card-title"><i class="fas fa-user-shield"></i> Izin Akses Admin</span>
            </div>

            <div class="pdp-notice" style="margin-bottom:14px;">
                Hanya admin yang dicentang yang dapat melihat dan mengunduh file ini. Perubahan berlaku segera.
            </div>

            <form action="{{ route('superadmin.files.permissions', $dataFile) }}" method="POST">
                @csrf @method('PUT')

                @if($allAdmins->isEmpty())
                    <div class="alert alert-warning"><i class="fas fa-info-circle"></i> Belum ada admin yang terdaftar.</div>
                @else
                <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(260px, 1fr)); gap:10px; margin-bottom:16px;">
                    @foreach($allAdmins as $admin)
                    <label style="display:flex; align-items:flex-start; gap:10px; padding:12px; border:1px solid {{ in_array($admin->id, $allowedIds) ? '#198754' : '#dee2e6' }}; border-radius:6px; cursor:pointer; font-size:13px; background:{{ in_array($admin->id, $allowedIds) ? '#f0fff4' : '#fff' }};">
                        <input type="checkbox" name="admin_ids[]" value="{{ $admin->id }}"
                            {{ in_array($admin->id, $allowedIds) ? 'checked' : '' }}
                            style="cursor:pointer; margin-top:2px;">
                        <div>
                            <strong>{{ $admin->name }}</strong>
                            @if(!$admin->is_active)
                                <span class="badge badge-inactive" style="margin-left:4px;">Nonaktif</span>
                            @endif
                            <div style="color:#6c757d; font-size:11px; margin-top:2px;">{{ $admin->instansi }}</div>
                            <div style="color:#adb5bd; font-size:11px;">{{ $admin->jabatan }}</div>
                        </div>
                    </label>
                    @endforeach
                </div>
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Perubahan Izin
                </button>
                @endif
            </form>
        </div>
    </div>

    <!-- Kanan: Permintaan & Stats -->
    <div>
        <div class="card">
            <div class="card-header">
                <span class="card-title">📊 Statistik</span>
            </div>
            <div style="font-size:13px;">
                <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f0f0;">
                    <span style="color:#6c757d;">Total Permintaan</span>
                    <strong>{{ $dataFile->dataRequests->count() }}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f0f0;">
                    <span style="color:#6c757d;">Disetujui</span>
                    <strong style="color:#198754;">{{ $dataFile->dataRequests->where('status','approved')->count() }}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f0f0;">
                    <span style="color:#6c757d;">Pending</span>
                    <strong style="color:#ffc107;">{{ $dataFile->dataRequests->where('status','pending')->count() }}</strong>
                </div>
                <div style="display:flex; justify-content:space-between; padding:6px 0;">
                    <span style="color:#6c757d;">Admin Diizinkan</span>
                    <strong>{{ count($allowedIds) }}</strong>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <span class="card-title">📋 Permintaan Terbaru</span>
            </div>
            @forelse($dataFile->dataRequests->take(5) as $req)
            <div style="padding:8px 0; border-bottom:1px solid #f0f0f0; font-size:12px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <strong>{{ $req->user->name ?? '—' }}</strong>
                    <span class="badge badge-{{ $req->status }}">{{ $req->status_label }}</span>
                </div>
                <div style="color:#adb5bd; margin-top:2px;">{{ $req->created_at->format('d/m/Y H:i') }}</div>
            </div>
            @empty
            <p style="color:#adb5bd; font-size:12px;">Belum ada permintaan.</p>
            @endforelse

            <a href="{{ route('superadmin.requests.index') }}" class="btn btn-sm btn-outline" style="margin-top:12px; width:100%; justify-content:center;">
                Lihat Semua Permintaan
            </a>
        </div>

        <div style="padding:12px; background:#fff3cd; border:1px solid #ffc107; border-radius:6px; font-size:11px; color:#664d03;">
            <strong>📝 UU PDP Pasal 47:</strong> Setiap akses ke file ini tercatat secara permanen dalam audit log dan tidak dapat dihapus secara manual.
        </div>
    </div>
</div>
@endsection
