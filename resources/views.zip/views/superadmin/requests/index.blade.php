@extends('layouts.app')
@section('page-title', 'Permintaan Data')

@section('content')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fas fa-inbox"></i> Daftar Permintaan Akses Data</span>
        <div style="display:flex; gap:8px; align-items:center;">
            <form method="GET" style="display:flex; gap:6px;">
                <select name="status" class="form-control" style="width:auto; padding:6px 10px; font-size:12px;" onchange="this.form.submit()">
                    <option value="">Semua Status</option>
                    <option value="pending"  {{ request('status')=='pending'  ? 'selected':'' }}>Pending</option>
                    <option value="approved" {{ request('status')=='approved' ? 'selected':'' }}>Disetujui</option>
                    <option value="rejected" {{ request('status')=='rejected' ? 'selected':'' }}>Ditolak</option>
                    <option value="revoked"  {{ request('status')=='revoked'  ? 'selected':'' }}>Dicabut</option>
                </select>
            </form>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Pemohon</th>
                    <th>File Data</th>
                    <th>NDA</th>
                    <th>Diajukan</th>
                    <th>Status</th>
                    <th>Download</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($requests as $req)
                <tr>
                    <td style="color:#adb5bd;">{{ $req->id }}</td>
                    <td>
                        <strong>{{ $req->user->name ?? '—' }}</strong>
                        <div style="font-size:11px; color:#6c757d;">{{ $req->user->instansi ?? '' }}</div>
                    </td>
                    <td>
                        <span style="font-size:13px;">{{ $req->dataFile->judul ?? '—' }}</span>
                        <div style="font-size:11px; color:#adb5bd;">{{ $req->dataFile->kategori_label ?? '' }} {{ $req->dataFile->tahun_data ? '· '.$req->dataFile->tahun_data : '' }}</div>
                    </td>
                    <td style="text-align:center;">
                        @if($req->nda_path)
                            <div style="display:flex; gap:6px; justify-content:center;">
                                <a href="{{ route('superadmin.requests.nda', $req) }}" target="_blank" class="btn btn-sm btn-outline" title="Lihat NDA">
                                    <i class="fas fa-file-pdf" style="color:#c62828;"></i>
                                </a>
                                <a href="{{ route('superadmin.requests.nda', ['dataRequest' => $req, 'mode' => 'download']) }}" class="btn btn-sm btn-outline" title="Unduh NDA">
                                    <i class="fas fa-download"></i>
                                </a>
                            </div>
                        @else
                            <span style="color:#adb5bd;">—</span>
                        @endif
                    </td>
                    <td style="font-size:12px; color:#6c757d; white-space:nowrap;">{{ $req->created_at->format('d/m/Y H:i') }}</td>
                    <td><span class="badge badge-{{ $req->status }}">{{ $req->status_label }}</span></td>
                    <td style="font-size:12px; text-align:center;">
                        @if($req->isApproved())
                            <span style="color:#0f5132;">{{ $req->download_count }}/{{ $req->max_downloads }}</span>
                        @else
                            <span style="color:#adb5bd;">—</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('superadmin.requests.show', $req) }}" class="btn btn-sm btn-outline">
                            <i class="fas fa-eye"></i> Review
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" style="text-align:center; color:#adb5bd; padding:32px;">
                        Tidak ada permintaan{{ request('status') ? ' dengan status '.request('status') : '' }}.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="margin-top:16px;">{{ $requests->links() }}</div>
</div>
@endsection
