@extends('layouts.app')
@section('page-title', 'Detail Permintaan Data')

@section('content')
<div style="display:grid; grid-template-columns:2fr 1fr; gap:20px;">
    <div>
        <!-- Info Pemohon -->
        <div class="card">
            <div class="card-header">
                <span class="card-title">📋 Detail Permintaan #{{ $dataRequest->id }}</span>
                <span class="badge badge-{{ $dataRequest->status }}">{{ $dataRequest->status_label }}</span>
            </div>

            <table style="width:100%; font-size:13px;">
                <tr><th style="width:160px; background:none; font-weight:600; padding:6px 0; border:none; color:#6c757d;">Pemohon</th><td style="padding:6px 0; border:none;">{{ $dataRequest->user->name }}</td></tr>
                <tr><th style="background:none; font-weight:600; padding:6px 0; border:none; color:#6c757d;">Instansi</th><td style="padding:6px 0; border:none;">{{ $dataRequest->user->instansi }}</td></tr>
                <tr><th style="background:none; font-weight:600; padding:6px 0; border:none; color:#6c757d;">File Diminta</th><td style="padding:6px 0; border:none;"><strong>{{ $dataRequest->dataFile->judul }}</strong></td></tr>
                <tr><th style="background:none; font-weight:600; padding:6px 0; border:none; color:#6c757d;">Dasar Hukum</th><td style="padding:6px 0; border:none;">{{ $dataRequest->dasar_hukum }}</td></tr>
                <tr><th style="background:none; font-weight:600; padding:6px 0; border:none; color:#6c757d;">Diajukan</th><td style="padding:6px 0; border:none;">{{ $dataRequest->created_at->format('d/m/Y H:i') }}</td></tr>
            </table>

            <div style="margin-top:14px;">
                <div style="font-size:12px; font-weight:600; color:#6c757d; margin-bottom:4px;">ALASAN PERMINTAAN</div>
                <div style="background:#f8f9fa; padding:12px; border-radius:4px; font-size:13px; line-height:1.6;">{{ $dataRequest->alasan_permintaan }}</div>
            </div>
            <div style="margin-top:12px;">
                <div style="font-size:12px; font-weight:600; color:#6c757d; margin-bottom:4px;">TUJUAN PENGGUNAAN</div>
                <div style="background:#f8f9fa; padding:12px; border-radius:4px; font-size:13px; line-height:1.6;">{{ $dataRequest->tujuan_penggunaan }}</div>
            </div>

            @if($dataRequest->nda_path)
            <div style="margin-top:14px; padding:12px; background:#e8f5e9; border-radius:6px; font-size:13px; display:flex; justify-content:space-between; gap:12px; align-items:center;">
                <div>
                    <i class="fas fa-file-pdf" style="color:#c62828;"></i>
                    <strong>NDA Terlampir:</strong> {{ $dataRequest->nda_filename }}
                </div>
                <div style="display:flex; gap:8px;">
                    <a href="{{ route('superadmin.requests.nda', $dataRequest) }}" target="_blank" class="btn btn-sm btn-outline">
                        <i class="fas fa-eye"></i> Lihat
                    </a>
                    <a href="{{ route('superadmin.requests.nda', ['dataRequest' => $dataRequest, 'mode' => 'download']) }}" class="btn btn-sm btn-primary">
                        <i class="fas fa-download"></i> Unduh
                    </a>
                </div>
            </div>
            @endif
        </div>

        <!-- Log Download -->
        @if($dataRequest->downloadLogs->isNotEmpty())
        <div class="card">
            <div class="card-header"><span class="card-title">📥 Riwayat Download</span></div>
            <table style="font-size:12px; width:100%;">
                <thead><tr><th>Waktu</th><th>Admin</th><th>IP</th><th>Captcha</th><th>Status</th></tr></thead>
                <tbody>
                @foreach($dataRequest->downloadLogs as $log)
                <tr>
                    <td>{{ $log->downloaded_at->format('d/m/Y H:i:s') }}</td>
                    <td>
                        <strong>{{ $log->user->name ?? '—' }}</strong>
                        <div style="color:#adb5bd; font-size:10px;">{{ $log->user->instansi ?? '' }}</div>
                    </td>
                    <td>{{ $log->ip_address }}</td>
                    <td>{{ $log->captcha_passed ? '✅' : '❌' }}</td>
                    <td><span class="badge badge-{{ $log->status === 'success' ? 'approved' : 'rejected' }}">{{ $log->status }}</span></td>
                </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        @endif
    </div>

    <!-- Action Panel -->
    <div>
        @if($dataRequest->isPending())
        <div class="card" style="border-left:4px solid #ffc107;">
            <div class="card-header"><span class="card-title">✅ Setujui Permintaan</span></div>
            <form action="{{ route('superadmin.requests.approve', $dataRequest) }}" method="POST">
                @csrf
                <div class="form-group">
                    <label class="form-label">Catatan (opsional)</label>
                    <textarea name="catatan" class="form-control" rows="3" placeholder="Catatan atau syarat khusus..."></textarea>
                </div>
                <button type="submit" class="btn btn-success" style="width:100%;">
                    <i class="fas fa-check"></i> Setujui
                </button>
            </form>
        </div>

        <div class="card" style="border-left:4px solid #dc3545; margin-top:0;">
            <div class="card-header"><span class="card-title">❌ Tolak Permintaan</span></div>
            <form action="{{ route('superadmin.requests.reject', $dataRequest) }}" method="POST">
                @csrf
                <div class="form-group">
                    <label class="form-label">Alasan Penolakan <span class="required">*</span></label>
                    <textarea name="catatan" class="form-control" rows="3" required placeholder="Jelaskan alasan penolakan..."></textarea>
                </div>
                <button type="submit" class="btn btn-danger" style="width:100%;"
                    onclick="return confirm('Yakin menolak permintaan ini?')">
                    <i class="fas fa-times"></i> Tolak
                </button>
            </form>
        </div>
        @endif

        @if($dataRequest->isApproved())
        <div class="card" style="border-left:4px solid #198754;">
            <div class="card-header"><span class="card-title">ℹ️ Status</span></div>
            <div style="font-size:13px; margin-bottom:12px;">
                <div style="color:#0f5132; font-weight:600; margin-bottom:8px;">✅ Permintaan Disetujui</div>
                <div>Disetujui oleh: {{ $dataRequest->reviewer->name ?? '-' }}</div>
                <div>Pada: {{ $dataRequest->reviewed_at?->format('d/m/Y H:i') }}</div>
                <div style="margin-top:8px; color:#6c757d;">Download tersisa: {{ $dataRequest->max_downloads - $dataRequest->download_count }}×</div>
            </div>
            <form action="{{ route('superadmin.requests.revoke', $dataRequest) }}" method="POST">
                @csrf
                <div class="form-group">
                    <label class="form-label">Alasan Pencabutan <span class="required">*</span></label>
                    <textarea name="catatan" class="form-control" rows="2" required></textarea>
                </div>
                <button type="submit" class="btn btn-warning btn-sm" style="width:100%;"
                    onclick="return confirm('Yakin mencabut persetujuan ini?')">
                    <i class="fas fa-ban"></i> Cabut Persetujuan
                </button>
            </form>
        </div>
        @endif

        @if($dataRequest->catatan_reviewer)
        <div class="card">
            <div class="card-header"><span class="card-title">📝 Catatan Reviewer</span></div>
            <div style="font-size:13px; line-height:1.6;">{{ $dataRequest->catatan_reviewer }}</div>
        </div>
        @endif

        <a href="{{ route('superadmin.requests.index') }}" class="btn btn-outline" style="width:100%; justify-content:center; margin-top:4px;">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar
        </a>
    </div>
</div>
@endsection
